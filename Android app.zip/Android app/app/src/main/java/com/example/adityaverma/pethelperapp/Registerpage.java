package com.example.adityaverma.pethelperapp;


import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class Registerpage extends Activity {
    EditText email;
    EditText name;
    EditText pwd;
    EditText cpwd;
    TableOps tableOps;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registerpage);



        email = findViewById(R.id.edtemail);
        name = findViewById(R.id.edtname);
        pwd = findViewById(R.id.edtpwd);
        cpwd = findViewById(R.id.edtcpwd);
        tableOps = new TableOps(Registerpage.this);

    }
    public void register(View view)
    {
        String ump1=email.getText().toString();
        String ump2=name.getText().toString();
        String ump3=pwd.getText().toString();
        String ump4=cpwd.getText().toString();
        //logic of database record entry for mpin registration begins
        tableOps.OpentDatabase();
        boolean status=tableOps.InsertInfo(ump1, ump2, ump3, ump4);

        if (status && validate())
        {
            Toast.makeText(Registerpage.this,"Registraion Successful plz login",Toast.LENGTH_SHORT).show();

            Intent launchlogin = new Intent(Registerpage.this, login.class);
            startActivity(launchlogin);
        }else
        {
            Toast.makeText(Registerpage.this," Registration not succesful",Toast.LENGTH_SHORT).show();
        }

    }

    public boolean validate() {
        boolean valid = true;

        String Email = email.getText().toString();
        String Name = name.getText().toString();
        String Password = pwd.getText().toString();
        String Cpassword = cpwd.getText().toString();



        if (Email.isEmpty() || !android.util.Patterns.EMAIL_ADDRESS.matcher(Email).matches()) {
            email.setError("enter a valid email address");
            valid = false;
        } else {
            email.setError(null);
        }

        if (Name.isEmpty() || name.length() < 1 || name.length() > 20) {
            name.setError("Enter a valid name");
            valid = false;
        } else {
            name.setError(null);
        }

        if (Password.isEmpty() || Password.length() < 4 || Password.length() > 10) {
            pwd.setError("between 4 and 10 alphanumeric characters");
            valid = false;
        } else {
            pwd.setError(null);
        }


        if (Cpassword.isEmpty() ){
            cpwd.setError("Enter same password");
            valid = true;
        }
        if (Cpassword.matches(Password)){
            cpwd.setError("Null");
        }
        else {
            cpwd.setError("Enter same password");
        }


        return valid;
    }
}
