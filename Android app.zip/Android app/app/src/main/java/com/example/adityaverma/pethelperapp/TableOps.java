package com.example.adityaverma.pethelperapp;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

public class TableOps {
    Context context;
    DbTblCreator dbTblCreator;
    SQLiteDatabase sqLiteDatabase;

    TableOps(Context ctx) {
        context = ctx;
        dbTblCreator = new DbTblCreator(context, null, null, 0);
    }

    public void OpentDatabase() {
        sqLiteDatabase = dbTblCreator.getWritableDatabase();

    }

    public boolean InsertInfo(String email, String name, String pwd, String cpwd) {
        ContentValues arow = new ContentValues();
        arow.put(DbTblCreator.Email, email);
        arow.put(DbTblCreator.Name, name);
        arow.put(DbTblCreator.Password, pwd);
        arow.put(DbTblCreator.Cpassword, cpwd);

        sqLiteDatabase.insert(DbTblCreator.TABLE_NAME, null, arow);
        return true;
    }


    public boolean FindMPin(String email, String pwd) {
        Cursor rowref = sqLiteDatabase.rawQuery("SELECT * FROM " + DbTblCreator.TABLE_NAME + " WHERE " + DbTblCreator.Email + " = ? AND "+ DbTblCreator.Password + " =? ", new String[]{email,pwd});
        if (rowref.moveToNext()) {
            return true;
        } else {
            return false;
        }

    }
}
