package com.example.adityaverma.pethelperapp;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class Dashboard extends AppCompatActivity {

        EditText editText;
        EditText editText2;

        @Override
        protected void onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
            setContentView(R.layout.activity_dashboard);
            editText=(EditText) findViewById(R.id.edtemail);
            editText2=(EditText) findViewById(R.id.edtpwd);

        }
        public void funcCon(View view)
        {

        }

}