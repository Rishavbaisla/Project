package com.example.adityaverma.pethelperapp;

        import android.content.Intent;
        import android.support.v7.app.AppCompatActivity;
        import android.os.Bundle;
        import android.view.View;
        import android.widget.EditText;
        import android.widget.Toast;

public class login extends AppCompatActivity {
    EditText editText;
    EditText editText2;
    TableOps tableOps;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        editText=(EditText) findViewById(R.id.edtemail);
        editText2=(EditText) findViewById(R.id.edtpwd);
        tableOps=new TableOps(login.this);

    }
    public void funcLogin(View view)
    {
        String email =editText.getText().toString();
        String pwd =editText2.getText().toString();
        tableOps.OpentDatabase();
        boolean find=tableOps.FindMPin(email,pwd);
        if (find)
        {
            Toast.makeText(login.this, "Login successful",Toast.LENGTH_SHORT).show();

            Intent launchdashboard=new Intent(login.this,Dashboard.class);
            startActivity(launchdashboard);
        }else
        {
            Toast.makeText(login.this,"incorrect Pin.login unsuccesful",Toast.LENGTH_SHORT).show();
        }

    }
    public void onregister(View view)
    {
        Intent launchregister=new Intent(login.this,Registerpage.class);
         startActivity(launchregister);
    }
    }

