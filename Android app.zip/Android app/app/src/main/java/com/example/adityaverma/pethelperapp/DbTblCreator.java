package com.example.adityaverma.pethelperapp;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DbTblCreator extends SQLiteOpenHelper {
   public static final String DATABASE_NAME="archita.db";

   public static final String TABLE_NAME="tbl_record";
   public static final int DATABASE_VERSION=3;
    public static final String Email="email";
    public static final String Name="name";
    public static final String Password="pwd";
    public static final String Cpassword="cpwd";


    public DbTblCreator(Context context, String name, SQLiteDatabase.CursorFactory factory, int version) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }


    @Override
    public void onCreate(SQLiteDatabase db) {
        String CREATE_TABLE = " CREATE TABLE "+TABLE_NAME+ "(" +Email+ " VARCHAR(30) PRIMARY KEY, "+ Name+ " VARCHAR(40),"+ Password+ " VARCHAR(40), "+Cpassword+ " VARCHAR(40)"+ ")";
        db.execSQL(CREATE_TABLE);


    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {

    }

}
